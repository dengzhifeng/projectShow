import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c)),
  Menu: () => import('../..\\components\\menu\\index.vue' /* webpackChunkName: "components/menu" */).then(c => wrapFunctional(c.default || c)),
  ProjectItem: () => import('../..\\components\\projectItem\\index.vue' /* webpackChunkName: "components/project-item" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
