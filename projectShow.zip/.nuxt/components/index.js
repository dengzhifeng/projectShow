import { wrapFunctional } from './utils'

export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Menu } from '../..\\components\\menu\\index.vue'
export { default as ProjectItem } from '../..\\components\\projectItem\\index.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const LazyMenu = import('../..\\components\\menu\\index.vue' /* webpackChunkName: "components/menu" */).then(c => wrapFunctional(c.default || c))
export const LazyProjectItem = import('../..\\components\\projectItem\\index.vue' /* webpackChunkName: "components/project-item" */).then(c => wrapFunctional(c.default || c))
